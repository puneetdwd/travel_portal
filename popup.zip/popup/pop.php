<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="bootstrap-datetimepicker-master/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="bootstrap-datetimepicker-master/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
 <script src="magic.js"></script>



<style type="text/css">
#ajaxwaiting{
    width:137px;
    height:54px;
    opacity:0.4;
    position:absolute !important;   
    top:100px;
    left:45%;
    z-index:5000;
}
</style>
</head>
<body>

<div class="container">
  <h2>Large Modal</h2>
  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Large Modal</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">


<div class="row">
        <div class="col-md-12">
                        <div class="portlet light bordered">
                <!--<div class="portlet-body form">-->
                <form role="form" class="" method="post" id="myform" novalidate="novalidate">
    <div class="form-body">                
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label for="dtp_input1" class="control-label">Departure Date</label>
                    <div class="input-group date form_datetime" data-date="2017-08-16T07:00Z" data-date-format="yyyy-mm-dd HH:ii:ss" data-link-field="dtp_input1">
                        <input name="departure_date" id="departure_date" class="form-control" size="16" value="2017-08-16 12:00:00 " readonly="" aria-required="true" aria-invalid="false" type="text">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-th"></span></span>
                    </div>
                    <input id="dtp_input1" value="" type="hidden"><br>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                <label for="dtp_input1" class="control-label">Return Date</label>
                <div class="input-group date form_datetime" data-date="2017-08-17T018:00:00Z" data-date-format="yyyy-mm-dd HH:ii:ss" data-link-field="dtp_input1">
                <input name="return_date" id="return_date" class="form-control" size="16" value="" readonly="" onchange="check_date()" type="text">
                <span class="input-group-addon"><span class="glyphicon glyphicon-th"></span></span>
                </div>
                <label id="return_date-error" class="error" for="return_date"></label>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="form-group">
                <label class="control-label">From Location                                               
                <span class="required" aria-required="true"> * </span></label>
                <select id="from_city_id" name="from_city_id" class="form-control required select2me select2-hidden-accessible" data-placeholder="Select a From Location" aria-required="true" tabindex="-1" aria-hidden="true">
              
                <option value="DEL">Delhi</option>
                <option value="AGR">Agra</option>
                <option value="PNQ" selected>Pune</option>
                <option value="JAI">Jaipur</option>
                <option value="KTU">Kota</option>
                <option value="UDR">Udaipur</option>
                <option value="HYD">Hyderabad</option>
                </select>
                </div>
            </div>

            <div class="col-md-3">
                <div class="form-group">
                <label class="control-label">To Location                                               
                <span class="required" aria-required="true"> * </span></label>
                <select id="to_city_id" name="to_city_id" class="form-control required select2me select2-hidden-accessible" data-placeholder="Select a To Location" aria-required="true" tabindex="-1" aria-hidden="true">
                <option value="DEL">Delhi</option>
                <option value="AGR">Agra</option>
                <option value="PNQ">Pune</option>
                <option value="JAI">Jaipur</option>
                <option value="KTU">Kota</option>
                <option value="UDR">Udaipur</option>
                <option value="HYD">Hyderabad</option>
                </select>
                </div>
            </div>       
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class=" pull-right">                   
                
                <button type="submit" class="btn btn-success">Search <span class="fa fa-arrow-right"></span></button>

                    </div>
                </div>
            </div>
            </div>
        </form>
    </div>
</div>
</div>

        <div id="ajaxwaiting" style="display: none">                
            <img src="loading.gif" title="Loader" alt="Loader" />
        </div>


        <div class="row">
            <div class="col-md-12">
                <div class=" pull-right">
                <p id="found"></p>
                </div>
            </div>
        </div>

        <div class="table-responsive" id="display">  
        <table class="table">
        <thead>
          <tr>
            <th>#</th>
            <th>From Location</th>
            <th>To Location</th>
            <th>From Date & Time</th>
            <th>To Date & Time</th>
            <th>Total Journey Hours</th>
            <th>Total Air Fare</th>
          </tr>
        </thead>
        <tbody>
        </tbody>
        </table>
        </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>


</body>
</html>

